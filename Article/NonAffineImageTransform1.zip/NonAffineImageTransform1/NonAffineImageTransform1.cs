//---------------------------------------------------------
// NonAffineImageTransform1.cs (c) 2007 by Charles Petzold
//---------------------------------------------------------
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Petzold.NonAffineImageTransform1
{
    public partial class NonAffineImageTransform1 : Page
    {
        bool isDragging;
        int indexDragging;

        public NonAffineImageTransform1()
        {
            InitializeComponent();
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs args)
        {
            Point ptMouse = args.GetPosition(viewport3d);

            // Obtain the Visual3D objects under the mouse pointer.
            HitTestResult result = VisualTreeHelper.HitTest(viewport3d, ptMouse);

            // Cast result parameter to RayMeshGeometry3DHitTestResult.
            RayMeshGeometry3DHitTestResult resultMesh =
                                    result as RayMeshGeometry3DHitTestResult;

            // This should not happen, but play it safe anyway.
            if (resultMesh == null)
                return;

            // Obtain clicked ModelVisual3D.
            ModelVisual3D vis = resultMesh.VisualHit as ModelVisual3D;

            // This should not happen, but play it safe anyway.
            if (vis == null)
                return;

            // Determine which vertex the mouse is closest to.
            if (resultMesh.VertexWeight1 < resultMesh.VertexWeight2)
            {
                if (resultMesh.VertexWeight2 < resultMesh.VertexWeight3)
                    indexDragging = resultMesh.VertexIndex3;
                else
                    indexDragging = resultMesh.VertexIndex2;
            }
            else if (resultMesh.VertexWeight3 > resultMesh.VertexWeight1)
                indexDragging = resultMesh.VertexIndex3;
            else
                indexDragging = resultMesh.VertexIndex1;

            // Set the point & initiate dragging.
            mesh.Positions[indexDragging] = Simple2Dto3D(viewport3d, ptMouse);
            isDragging = true;
            CaptureMouse();
            args.Handled = true;
        }

        protected override void OnMouseMove(MouseEventArgs args)
        {
            base.OnMouseMove(args);

            if (isDragging)
            {
                Point ptMouse = args.GetPosition(viewport3d);
                mesh.Positions[indexDragging] = Simple2Dto3D(viewport3d, ptMouse);
                args.Handled = true;
            }
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs args)
        {
            base.OnMouseUp(args);

            if (isDragging)
            {
                isDragging = false;
                ReleaseMouseCapture();
                args.Handled = true;
            }
        }

        // The following two methods only work with OrthographicCamera,
        // with LookDirection of (0, 0, -1) and UpDirection of (0, 1, 0).
        // More advanced conversion routines can be found in the 
        // Petzold.Media3D library.

        // Converts a 2D point in device-independent coordinates relative 
        //  to Viewport3D to 3D space.
        Point3D Simple2Dto3D(Viewport3D vp, Point pt)
        {
            OrthographicCamera cam = CheckRestrictions(vp);
            double scale = cam.Width / vp.ActualWidth;
            double x = scale * (pt.X - vp.ActualWidth / 2) + cam.Position.X;
            double y = scale * (vp.ActualHeight / 2 - pt.Y) + cam.Position.Y;

            return new Point3D(x, y, 0);
        }

        // Converts a 3D point to 2D in device-independent coordinates
        //  relative to Viewport3D.
        Point Simple3Dto2D(Viewport3D vp, Point3D point)
        {
            OrthographicCamera cam = CheckRestrictions(vp);
            double scale = vp.ActualWidth / cam.Width;
            double x = vp.ActualWidth / 2 + scale * (point.X - cam.Position.X);
            double y = vp.ActualHeight / 2 - scale * (point.Y - cam.Position.Y);
            return new Point(x, y);
        }

        OrthographicCamera CheckRestrictions(Viewport3D vp)
        {
            OrthographicCamera cam = vp.Camera as OrthographicCamera;

            if (cam == null)
                throw new ArgumentException("Camera must be OrthographicCamera");

            if (cam.LookDirection != new Vector3D(0, 0, -1))
                throw new ArgumentException("Camera LookDirection must be (0, 0, -1)");

            if (cam.UpDirection != new Vector3D(0, 1, 0))
                throw new ArgumentException("Camera UpDirection must be (0, 1, 0)");

            return cam;
        }
    }
}
